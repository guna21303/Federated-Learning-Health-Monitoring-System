import flwr as fl

strategy = fl.server.strategy.FedAvg()

if __name__ == "__main__":
    print("Starting Federated Learning Server...")
    fl.server.start_server(
        server_address="localhost:8080",
        config=fl.server.ServerConfig(num_rounds=3),
        strategy=strategy,
    )

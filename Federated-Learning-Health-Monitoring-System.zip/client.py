import flwr as fl

class HealthClient(fl.client.NumPyClient):
    def get_parameters(self, config):
        return []

    def fit(self, parameters, config):
        print("Training local health model...")
        return [], 100, {}

    def evaluate(self, parameters, config):
        print("Evaluating model...")
        return 0.1, 100, {"accuracy": 0.95}

if __name__ == "__main__":
    fl.client.start_numpy_client(server_address="localhost:8080", client=HealthClient())
